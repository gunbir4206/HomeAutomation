//mypthread.c

#include "mypthread.h"


typedef struct threadNode{
    
// Type your commands

}Node;

//Global

// Type your globals...

// Type your own functions (void)
// e.g., free up sets of data structures created in your library

    
/*  Write your thread create function here...
int mypthread_create(mypthread_t *thread, ....)  */
	

*/ Write your thread exit function here...
void mypthread_exit (... )...    */
  
    
*/ Write your thread yield function here...
void mypthread_yield (... )...    */

*/  Write your thread join function here...
  void mypthread_join (... )...    */
    
/* Write whatever function is left here ....
  void mypthread_whatever (... ) ...