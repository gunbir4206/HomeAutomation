package com.example.aaronchristie.myapplication1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DoorLock extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_door_lock);

      //  final Button bUpdateLock = (Button) findViewById(R.id.bUpdateLock);



       /* updateLockStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent updateLockStatusIntent = new Intent(DoorLock.this, updateLockStatus.class);
                DoorLock.this.startActivity(updateLockStatusIntent);
            }
        }); */


        }
    }

